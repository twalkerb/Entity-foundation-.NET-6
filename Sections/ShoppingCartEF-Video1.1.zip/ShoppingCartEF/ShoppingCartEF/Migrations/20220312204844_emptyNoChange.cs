﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ShoppingCartEF.Migrations
{
    public partial class emptyNoChange : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
